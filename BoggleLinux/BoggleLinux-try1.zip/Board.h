/* 
 * File:   Board.h
 * Author: robert
 *
 * Created on February 9, 2013, 10:05 PM
 */
#include <cstdlib>
#include <vector>
#include <set>
#include <string>
#include "Dictionary.h"
#include "Point.h"

#ifndef BOARD_H
#define	BOARD_H

using namespace std;

typedef set<Point> Points;

class Board {
public:
    Board();
    Board(const Board& orig);
    virtual ~Board();
    
    set<string> foundWords;
    vector< vector<string> > board;
    
    void loadFile(char* filename);
    set<string> findAllInDictionary(Dictionary &dictionary);
    string printBoard();
    
    set<string>find(Point point, Dictionary &dictionary, set<string> &foundWords, Points &usedPoints, string word);

private:
    string _createPoint(int row, int column);
};

#endif	/* BOARD_H */

