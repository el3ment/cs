// http://www.dave-reed.com/Nifty/randSeq.html

#include <cstdlib>
#include <iostream>
#include <fstream>
#include "Board.h"
#include "Dictionary.h"
#include "Point.h"
using namespace std;

int main(int argc, char** argv) {
    
    ofstream outputFile(argv[3]);
    
    Dictionary dictionary;
    dictionary.loadFile(argv[1]);

    Board board;
    board.loadFile(argv[2]);
    outputFile << board.printBoard() << endl;
    
    set<string> foundWords = board.findAllInDictionary(dictionary);
    
    for(set<string>::iterator i = foundWords.begin(); i != foundWords.end(); i++){
        outputFile << *i << endl;
    }

        
    ifstream print(argv[3]);
    string line;
    while(getline(print, line)){
        cout << line << endl;
    }
    
    return 0;
}

