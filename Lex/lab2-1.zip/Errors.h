/* 
 * File:   Errors.h
 * Author: robert
 *
 * Created on February 20, 2014, 9:52 PM
 */

#ifndef ERRORS_H
#define	ERRORS_H

const int UNEXPECTED_TOKEN = 1;

#endif	/* ERRORS_H */

