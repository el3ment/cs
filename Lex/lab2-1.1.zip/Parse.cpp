#include "Lex.h"
#include "Parse.h"
#include "TokenType.h"
#include "Errors.h"
#include <string>
#include <iostream>

using namespace std;

Parse::Parse() {
}

Parse::Parse(const char* fileName){
	lexicalStructure = new Lex(fileName);
}

Parse::Parse(const Parse& orig){}

Parse::~Parse() {
	delete lexicalStructure;
}

string Parse::parse(){
    
	string output;
	
	try{
		Datalog* data = new Datalog(*lexicalStructure);
		output += "Success!\n";
		output += data->toString();
		delete data;
	}catch(int e){
		switch(e){
			case UNEXPECTED_TOKEN:
				output ="Failure!\n";
				output += "  ";
				output += lexicalStructure->getCurrentToken()->toString();
				break;
			default:
				cout << "Unknown error";
				break;
		}
	}
	
	return output;
}

int main(int argc, char* argv[]) {
   
	
   
	Parse parser = Parse("active");
	cout << parser.parse();
    

    return 0;
}
